# Nama Kelompok
Bariancrot

# Petunjuk Penggunaan Program
jalankan pada command prompt dengan directory file tersebut:
    python server.py

# Pembagian Tugas
+----------+--------------------+----------------------------------------------+-----------------------+
|   NIM    |        Nama        |             Apa yang Dikerjakan              | Persentase Kontribusi |
+----------+--------------------+----------------------------------------------+-----------------------+
| 13517027 | M.Raihan Asyraf D. | Membuat handshake dan solusi test case 3     | 33%                   |
| 13517051 | Hamzah C.          | Membuat Control frame dan solusi test case 1 | 33%                   |
| 13517111 | Paulus H.D.        | Membuat framing dan solusi test case 2       | 33%                   |
+----------+--------------------+----------------------------------------------+-----------------------+


