# Nama Kelompok
Bariancrot

# Petunjuk Penggunaan Program (submisi ke jarkom.tenshi.dev
jalankan pada command prompt dengan directory file tersebut:
    python server.py
jalankan ngrok.exe
ketik command
	ngrok http 6969
copy forwarding address, lalu ganti http dengan ws
bukan jarkom.tenshi.dev/submission
masukkan nim, nama kelompok dan alamat forwarding yang http sudah diganti, misal:
	ws://3ee3cc43.ngrok.io 
submit, lalu masukkan token
biarkan program di-grading.
	
# Pembagian Tugas
+----------+--------------------+----------------------------------------------+-----------------------+
|   NIM    |        Nama        |             Apa yang Dikerjakan              | Persentase Kontribusi |
+----------+--------------------+----------------------------------------------+-----------------------+
| 13517027 | M.Raihan Asyraf D. | Membuat handshake dan solusi test case 3     | 33%                   |
| 13517051 | Hamzah C.          | Membuat Control frame dan solusi test case 1 | 33%                   |
| 13517111 | Paulus H.D.        | Membuat framing dan solusi test case 2       | 33%                   |
+----------+--------------------+----------------------------------------------+-----------------------+


